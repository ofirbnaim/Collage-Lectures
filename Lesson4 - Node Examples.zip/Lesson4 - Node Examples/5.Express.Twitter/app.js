var app = require('express').createServer(),
    twitter = require('ntwitter');

app.listen(8080);

var twit = new twitter({
  consumer_key: 'bbdX49yMUm8kFfA5dvz7w',
  consumer_secret: 'de5yQ7a4vMtmBRIUNm9G3N2tQwu3ZkXtlSNghvxFi8',
  access_token_key: '2263037082-ZEAEaOc4BhL5BBRcXtaVYVVhxIGhWOp5L5Q3aTP',
  access_token_secret: 'PflYlCAhtu28sWC4IGTMoQ2OD99upbzlUdoMf90R7B3A9'
});


twit.stream('statuses/filter', { track: ['love', 'hate'] }, function(stream) {
  stream.on('data', function (data) {
     console.log(data);
  });
});


