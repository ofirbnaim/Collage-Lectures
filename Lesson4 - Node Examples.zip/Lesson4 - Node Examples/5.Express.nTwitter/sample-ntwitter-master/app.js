
/**
 * Module dependencies.
 Added
 1. ntwitter - package for using Twitter API
 2. url - used to parse out different parts of URLs
 */

 var express = require('express')
 , routes = require('./routes')
 , http = require('http')
 , path = require('path')
 , ntwitter = require('ntwitter');

 var app = express();

 app.configure(function(){
  app.set('port', process.env.PORT || 8080);
  app.set('views', __dirname + '/views');
  app.set('view engine', 'jade');
  app.use(express.favicon());
  app.use(express.logger('dev'));
  app.use(express.bodyParser());
  app.use(express.methodOverride());
  app.use(express.cookieParser('secretsession'));
  app.use(express.session());
  app.use(app.router);
  app.use(express.static(path.join(__dirname, 'public')));
});

 app.configure('development', function(){
  app.use(express.errorHandler());
});


    app.get('/', function(req, res){
      console.log("Entering Single User Example...");

   var twit = new ntwitter({
  consumer_key: 'bbdX49yMUm8kFfA5dvz7w',
  consumer_secret: 'de5yQ7a4vMtmBRIUNm9G3N2tQwu3ZkXtlSNghvxFi8',
  access_token_key: '2263037082-ZEAEaOc4BhL5BBRcXtaVYVVhxIGhWOp5L5Q3aTP',
  access_token_secret: 'PflYlCAhtu28sWC4IGTMoQ2OD99upbzlUdoMf90R7B3A9'
  });

   twit.verifyCredentials(function (err, data) {
    console.log("Verifying Credentials...");
    if(err)
      console.log("Verification failed : " + err)
  })
   .getHomeTimeline('',
    function (err, data) {
      console.log("Timeline Data Returned....");
      // console.log(data);

      var view_data = {
        "timeline" : JSON.stringify(data)
      }

      console.log("Exiting Controller.");
      
      res.render('single',view_data);
    });
 });


 
http.createServer(app).listen(app.get('port'), function(){
  console.log("Express server listening on port " + app.get('port'));
});

