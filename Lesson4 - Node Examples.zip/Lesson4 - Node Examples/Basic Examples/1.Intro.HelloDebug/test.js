var http = require('http');
http.createServer(function(request, response) {
  response.writeHead(200);
var a=10;
var b=5;
var c=a*b;
    response.write("Hello "+c);
  response.end();
}).listen(8080);
console.log("Listening on port 8080...");
