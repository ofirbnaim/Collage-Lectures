var express = require("express");
var app = express(); // express.createServer();
var msgs = [];

app.get("/message", function(request, response){
	msgs.push({ usename : request.query.uname, message:  request.query.mes});
	response.json(msgs);
});

app.get("/chat", function(request, response){
	response.json(msgs);
});


app.get("/", function(request, response){
    response.sendfile(__dirname + "/index.html");


});

app.listen(8080);